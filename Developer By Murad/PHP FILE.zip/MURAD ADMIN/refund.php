<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'];
    $match_id = $_POST['match_id'];
    $email = $_POST['email'];
    $joiner_id = $_POST['joiner_id'];
    $entry_fee = $_POST['entry_fee'];

    $sql = "UPDATE users SET balance = balance + $entry_fee WHERE email = '$email'";
    $delete = "DELETE FROM joiners WHERE type = '$type' AND id = $joiner_id";
    $update = "UPDATE `$type` SET total_joiner = total_joiner - 1 WHERE id = $match_id";

    if ($conn->query($sql) === TRUE && $conn->query($delete) === TRUE && $conn->query($update) === TRUE) {
        echo "Refund Successfully";
    } else {
        echo "Error Refunding: " . $conn->error;
    }

    $conn->close();
} else {
    echo "Invalid Request Method";
}
?>