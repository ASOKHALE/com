<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $table = $_POST['table'];
    
    $sql = "DELETE FROM $table";

    if ($conn->query($sql) === TRUE) {
        echo "All Records Deleted Successfully";
    } else {
        echo "Error Deleting Records: " . $conn->error;
    }

    $conn->close();
} else {
    echo "Invalid Request Method";
}
?>