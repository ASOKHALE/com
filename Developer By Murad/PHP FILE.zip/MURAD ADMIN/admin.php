<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'];

    if ($type === 'login') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $query = "SELECT * FROM admin WHERE username = '$username'";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            $admin = $result->fetch_assoc();
            if ($admin['password'] === $password) {
                echo "Login Success";
            } else {
                echo "Invalid Password";
            }
        } else {
            echo "No Admin Found";
        }
    }
    
    if ($type === 'change') {
        $old_pass = $_POST['old_pass'];
        $new_pass = $_POST['new_pass'];
        
        $query = "SELECT * FROM admin WHERE password = '$old_pass'";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            $admin = $result->fetch_assoc();
            $username = $admin["username"];
            
            $update = "UPDATE admin SET password = '$new_pass' WHERE username = '$username'";
            
            if ($conn->query($update) === TRUE) {
                echo "Changed Successfully";
            } else {
                echo "Error Changing: " . $conn->error;
            }
        } else {
            echo "Old Password Is Incorrect";
        }
    }
    $conn->close();
} else {
    echo "Invalid Request Method";
}
?>