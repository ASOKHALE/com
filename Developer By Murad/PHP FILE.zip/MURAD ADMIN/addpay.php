<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $gateway = $_POST["Gateway"];
    $method = $_POST["Method"];
    $amount = $_POST["Amount"];
    $sender = $_POST["Sender"];
    $trxid = $_POST["TrxID"];

    $insert = "INSERT INTO transaction (gateway, method, amount, sender, trxid) VALUES ('$gateway', '$method', '$amount', '$sender', '$trxid')";

    if ($conn->query($insert) === TRUE) {
        echo "Message Receive Successfully";
    } else {
        echo "Error Receive Message: " . $conn->error;
    }
    $conn->close();
} else {
    echo "Invalid Request Method";
}
?>